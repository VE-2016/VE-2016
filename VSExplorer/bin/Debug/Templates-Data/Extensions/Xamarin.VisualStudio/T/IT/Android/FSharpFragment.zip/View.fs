﻿
namespace $rootnamespace$

open System
open System.Collections.Generic
open System.Linq
open System.Text

open Android.App
open Android.Content
open Android.OS
open Android.Runtime
open Android.Util
open Android.Views
open Android.Widget

type $safeitemrootname$ () =
  inherit Fragment ()

  override this.OnCreate (savedInstanceState) =
    base.OnCreate (savedInstanceState)
    // Create your fragment here

