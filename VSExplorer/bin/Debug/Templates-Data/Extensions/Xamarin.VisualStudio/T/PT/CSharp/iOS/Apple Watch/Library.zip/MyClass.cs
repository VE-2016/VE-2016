﻿using System;

namespace $safeprojectname$
{
	public class MyClass
	{
		public MyClass()
		{
		}
	}
}
