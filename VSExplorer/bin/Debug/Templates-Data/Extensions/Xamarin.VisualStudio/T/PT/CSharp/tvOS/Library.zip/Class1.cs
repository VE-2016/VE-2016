﻿using System;

namespace $safeprojectname$
{
	public class Class1
	{
		public Class1 ()
		{
		}
	}
}

