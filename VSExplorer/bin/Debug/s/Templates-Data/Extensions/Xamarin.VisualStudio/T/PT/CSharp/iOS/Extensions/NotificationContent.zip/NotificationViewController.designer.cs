﻿//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;

namespace $safeprojectname$
{
	[Register("NotificationViewController")]
	partial class NotificationViewController
	{
		[Outlet]
		UIKit.UILabel label { get; set; }

		void ReleaseDesignerOutlets()
		{
		}
	}
}
