﻿//
// This file has been generated automatically to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;

namespace $safeprojectname$
{
	[Register ("ViewController")]
	partial class ViewController
	{
		void ReleaseDesignerOutlets ()
		{
		}
	}
}
