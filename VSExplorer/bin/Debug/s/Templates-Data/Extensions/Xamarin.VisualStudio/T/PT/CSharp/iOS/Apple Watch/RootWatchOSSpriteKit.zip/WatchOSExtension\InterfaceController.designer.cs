﻿using Foundation;
using System.CodeDom.Compiler;

namespace $safeprojectname$
{
	[Register("InterfaceController")]
	partial class InterfaceController
	{
		[Outlet]
		WatchKit.WKInterfaceSKScene skInterface { get; set; }

		void ReleaseDesignerOutlets()
		{
		}
	}
}
