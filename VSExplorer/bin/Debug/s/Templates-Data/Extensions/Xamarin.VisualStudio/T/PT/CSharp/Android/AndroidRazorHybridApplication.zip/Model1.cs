﻿using System;

namespace $safeprojectname$.Models
{
	public class Model1
	{
		public string Text { get; set; }
	}
}
