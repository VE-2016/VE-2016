﻿using Foundation;
using System.CodeDom.Compiler;

namespace $safeprojectname$
{
	[Register("InterfaceController")]
	partial class InterfaceController
	{
		[Outlet]
		WatchKit.WKInterfaceSCNScene scnInterface { get; set; }

		void ReleaseDesignerOutlets()
		{
		}
	}
}
