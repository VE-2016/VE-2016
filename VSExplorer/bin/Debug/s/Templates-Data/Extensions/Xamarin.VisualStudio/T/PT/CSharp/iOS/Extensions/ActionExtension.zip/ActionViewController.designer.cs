﻿//
// This file has been generated automatically to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using UIKit;
using Foundation;

namespace $safeprojectname$
{
	[Register ("ActionViewController")]
	partial class ActionViewController
	{
		[Outlet]
		UIImageView imageView { get; set; }

		[Action ("DoneClicked:")]
		partial void DoneClicked (NSObject sender);

		void ReleaseDesignerOutlets ()
		{
		}
	}
}