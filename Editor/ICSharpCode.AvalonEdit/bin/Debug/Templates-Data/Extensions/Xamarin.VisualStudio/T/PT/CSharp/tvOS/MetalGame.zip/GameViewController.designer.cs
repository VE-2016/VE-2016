﻿using Foundation;
using System.CodeDom.Compiler;

namespace $safeprojectname$
{
	[Register ("GameViewController")]
	partial class GameViewController
	{
		void ReleaseDesignerOutlets ()
		{
		}
	}
}

