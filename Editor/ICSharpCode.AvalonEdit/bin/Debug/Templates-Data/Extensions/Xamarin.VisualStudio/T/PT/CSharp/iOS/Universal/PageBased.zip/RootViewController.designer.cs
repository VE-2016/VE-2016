﻿using Foundation;
using System.CodeDom.Compiler;

namespace $safeprojectname$
{
	[Register ("RootViewController")]
	partial class RootViewController
	{
		void ReleaseDesignerOutlets ()
		{
		}
	}
}

