﻿using System;

using Foundation;
using WatchKit;

namespace $safeprojectname$
{
	public class ExtensionDelegate : WKExtensionDelegate
	{
		public ExtensionDelegate ()
		{
		}
	}
}

