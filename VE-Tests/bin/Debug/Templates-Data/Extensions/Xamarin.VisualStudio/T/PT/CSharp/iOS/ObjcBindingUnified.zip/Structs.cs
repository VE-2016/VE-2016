﻿using System;

namespace $safeprojectname$
{
}

