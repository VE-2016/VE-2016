﻿namespace $safeprojectname$

type Class1() = 
    member this.X = "F#"
